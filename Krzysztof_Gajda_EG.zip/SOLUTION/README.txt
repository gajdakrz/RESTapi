1. INTRODUTION
	This web application with RESTful api is based on codeigniter 3.1.1 framework and mysql database.
	Tests based on postman addons (https://chrome.google.com/webstore/detail/postman/fhbjgbiflinjbdggehcddcbncdddomop?hl=pl)

2. INSTALATION
	2.1. Datatabase - create api database
		- run sql script from: /database/api.sql
	2.1. Application
		- insert 'products' folder from: /app/products into your host (this solution was prepared on localhost)
3.	CONFIGURATION
	3.1 Most important files in the application
		- configuration: /app/products/application/config/
		- rest api solution: /app/products/application/controllers/api/
	3.1. DB connection
		- modify /app/products/application/config/database.php and add your 'username' and 'password' for db connection
4. TESTING/app/products/application/config/
	For test rest api it is possible to use postman addons for chrome.
	POST/PUT data are sending in format: x-www-form-urlencoded (in the postman this is the option to choose for body->x-www-form-urlencoded)
	
	REST api test options (this solution was prepared on localhost):
	4.1 POST data
	- create product: http://localhost/index.php/api/Product
	- create cart: http://localhost/index.php/api/Cart
	- create cartItem: http://localhost/index.php/api/Cartitem (if 'cart_id' is not posted - also new cart will be created and id_cart added to cartitem)
	4.2 PUT data
	- update product with id = 1: http://localhost/index.php/api/Product/1
	- update cart with id = 1: http://localhost/index.php/api/Cart/1
	- update cartItem with id = 1: http://localhost/index.php/api/Cartitem/1
	4.3 DELETE data
	- delete product with id = 1: http://localhost/index.php/api/Product/1
	- delete cart with id = 1: http://localhost/index.php/api/Cart/1
	- delete cartItem with id = 1: http://localhost/index.php/api/Cartitem/1
	4.3 GET all data
	- get all products: http://localhost/index.php/api/Product
	- get all carts: http://localhost/index.php/api/Cart
	- get all cartItems: http://localhost/index.php/api/Cartitem
	4.4 GET data with id
	- get product with id = 1: http://localhost/index.php/api/Product/1
	- get all cart with id = 1: http://localhost/index.php/api/Cart/1
	- get all cartItem with id = 1: http://localhost/index.php/api/Cartitem/1